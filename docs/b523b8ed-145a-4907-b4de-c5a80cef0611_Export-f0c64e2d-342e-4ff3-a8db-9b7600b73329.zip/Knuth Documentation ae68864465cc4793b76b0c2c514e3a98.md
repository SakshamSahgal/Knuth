# Knuth Documentation

![KnuthLogo.png](Knuth%20Documentation%20ae68864465cc4793b76b0c2c514e3a98/KnuthLogo.png)

[Running The Project Locally](Knuth%20Documentation%20ae68864465cc4793b76b0c2c514e3a98/Running%20The%20Project%20Locally%20154d227a73e547aeaea03074ca90cb64.md)

[APIs](Knuth%20Documentation%20ae68864465cc4793b76b0c2c514e3a98/APIs%20fb7ca45d2ddb411b81f640898cd1a0cf.md)

[Packages Used](Knuth%20Documentation%20ae68864465cc4793b76b0c2c514e3a98/Packages%20Used%20562ef0a62caa4062b79b33595f62e0ca.md)

[Configuration Parameters](Knuth%20Documentation%20ae68864465cc4793b76b0c2c514e3a98/Configuration%20Parameters%205b8ff156f01b4e9b905a85c438348086.md)